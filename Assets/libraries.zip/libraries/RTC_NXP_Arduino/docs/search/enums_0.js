var searchData=
[
  ['alarm_5fsetting_0',['alarm_setting',['../class_r_t_c___n_x_p.html#aa11396067a7c0e240e169d4862539866',1,'RTC_NXP']]],
  ['alarm_5fsetting_5f85263a_1',['alarm_setting_85263A',['../class_p_c_f85263_a.html#a9022b57b3608c69e928ee5219b17cc34',1,'PCF85263A']]]
];
