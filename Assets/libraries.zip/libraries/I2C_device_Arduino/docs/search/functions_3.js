var searchData=
[
  ['ping_0',['ping',['../class_i2_c__device.html#a2298c86cb79fdbb630a909c1ca970b05',1,'I2C_device::ping(void)'],['../class_i2_c__device.html#a9827d0dd088d394df1d78e0e41573baf',1,'I2C_device::ping(uint8_t addr)']]]
];
