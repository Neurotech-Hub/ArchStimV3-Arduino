var searchData=
[
  ['getting_20started_0',['Getting started',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
