var searchData=
[
  ['timestamp_5fsetting_0',['timestamp_setting',['../class_p_c_f2131__base.html#a0285f08aba6bfa062f41f2f436c4aa8f',1,'PCF2131_base::timestamp_setting'],['../class_p_c_f2131___i2_c.html#a1599642f97216bb88308a59d913956f2',1,'PCF2131_I2C::timestamp_setting'],['../class_p_c_f2131___s_p_i.html#aa655b90d1a7ea9e9e57860364807855d',1,'PCF2131_SPI::timestamp_setting']]],
  ['ts_5fin_1',['ts_in',['../class_p_c_f85263_a.html#a5a002fd033a255abadc485673a13f632',1,'PCF85263A']]]
];
