var searchData=
[
  ['rtc_5fnxp_5farduino_0',['RTC_NXP_Arduino',['../md__r_e_a_d_m_e.html',1,'']]]
];
