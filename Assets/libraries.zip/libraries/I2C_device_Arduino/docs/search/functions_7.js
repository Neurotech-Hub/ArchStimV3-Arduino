var searchData=
[
  ['write_5fr16_0',['write_r16',['../class_i2_c__device.html#aa7db320551353b8d860221dc646f3989',1,'I2C_device']]],
  ['write_5fr8_1',['write_r8',['../class_i2_c__device.html#a5f69560e9cb2d8ec33f2f5f8d497a34e',1,'I2C_device']]]
];
