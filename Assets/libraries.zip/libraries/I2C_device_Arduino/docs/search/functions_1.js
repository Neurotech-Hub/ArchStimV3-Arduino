var searchData=
[
  ['i2c_5fdevice_0',['I2C_device',['../class_i2_c__device.html#ad80b4138d2345ca258c9f33930853bc7',1,'I2C_device::I2C_device(uint8_t i2c_address, bool repeated_start_enable=true)'],['../class_i2_c__device.html#ab8dae8d06ba97ffc06abc4c49c48d3b1',1,'I2C_device::I2C_device(TwoWire &amp;wire, uint8_t i2c_address, bool repeated_start_enable=true)']]]
];
