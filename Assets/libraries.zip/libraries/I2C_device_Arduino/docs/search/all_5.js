var searchData=
[
  ['libraries_0',['Related libraries',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]]
];
