var searchData=
[
  ['bit_5fop16_0',['bit_op16',['../class_i2_c__device.html#abd030d701ee101dbf359c05eddab50cf',1,'I2C_device']]],
  ['bit_5fop8_1',['bit_op8',['../class_i2_c__device.html#a758abf4ad6fdca6d32c06ab7780b13b5',1,'I2C_device']]]
];
