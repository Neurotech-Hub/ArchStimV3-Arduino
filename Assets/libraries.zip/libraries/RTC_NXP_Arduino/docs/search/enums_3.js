var searchData=
[
  ['inta_0',['inta',['../class_p_c_f85263_a.html#a8cd044df48a2001ac2514e5a2dd8dad6',1,'PCF85263A']]],
  ['intb_1',['intb',['../class_p_c_f85263_a.html#a1816caad9f3a66240bd899c2a2d6d2ae',1,'PCF85263A']]]
];
