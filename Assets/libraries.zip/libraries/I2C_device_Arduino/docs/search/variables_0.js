var searchData=
[
  ['i2c_0',['i2c',['../class_i2_c__device.html#a946e117192be1ed0499e509ca7e9482e',1,'I2C_device']]],
  ['i2c_5faddr_1',['i2c_addr',['../class_i2_c__device.html#ac1690942862f4dac204ff918b1f8ca48',1,'I2C_device']]]
];
