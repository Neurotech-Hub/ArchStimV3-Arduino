var searchData=
[
  ['examples_0',['Examples',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
