var searchData=
[
  ['read_0',['read',['../classtest___l_m75_b.html#ac2873766359521441c474fa01a802c60',1,'test_LM75B']]],
  ['read_5fr16_1',['read_r16',['../class_i2_c__device.html#a9aa5aff32f1484d2282decfa0307c38d',1,'I2C_device']]],
  ['read_5fr8_2',['read_r8',['../class_i2_c__device.html#a422a498c526852b38836a6313e14e371',1,'I2C_device']]],
  ['reg_5fr_3',['reg_r',['../class_i2_c__device.html#aacf224bbce4f0c28a11b2b1355f36ca9',1,'I2C_device::reg_r(uint8_t reg_adr, uint8_t *data, uint16_t size)'],['../class_i2_c__device.html#a8380ce4dd6211b4cc7d5e48bdb473854',1,'I2C_device::reg_r(uint8_t reg_adr)']]],
  ['reg_5fw_4',['reg_w',['../class_i2_c__device.html#a5b6217e349b8f70ecfb7a75435b8694f',1,'I2C_device::reg_w(uint8_t reg_adr, const uint8_t *data, uint16_t size)'],['../class_i2_c__device.html#a76e502bad7038b7d534140931d0ccc27',1,'I2C_device::reg_w(uint8_t reg_adr, uint8_t data)']]],
  ['repeated_5fstart_5fenable_5',['repeated_start_enable',['../class_i2_c__device.html#aa7e393f9d636f9703047a96761828ade',1,'I2C_device']]],
  ['rx_6',['rx',['../class_i2_c__device.html#a371e31074e312ef7718ce71708f265c3',1,'I2C_device']]]
];
