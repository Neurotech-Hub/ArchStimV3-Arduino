var searchData=
[
  ['s_20inside_0',['What&apos;s inside?',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['sample_1',['Code sample',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['sample_20code_2',['List of sample code',['../md__r_e_a_d_m_e.html#autotoc_md8',1,'']]],
  ['set_3',['set',['../class_r_t_c___n_x_p.html#a2e40b668541081005362fbfb287c182f',1,'RTC_NXP::set()'],['../class_p_c_f2131__base.html#a3d59a120d2836fc9ddb2348993c2e94f',1,'PCF2131_base::set()'],['../class_p_c_f2131___i2_c.html#a2b9cb78248f8f9aefcf439bc1adae389',1,'PCF2131_I2C::set()'],['../class_p_c_f2131___s_p_i.html#aef062a54afeb23ade227e956173840a1',1,'PCF2131_SPI::set()'],['../class_p_c_f85063__base.html#a10b58d508f3cfdaedb86c603a327923e',1,'PCF85063_base::set()'],['../class_p_c_f85063_a.html#a90c19698171af0d85412a46b6588a893',1,'PCF85063A::set()'],['../class_p_c_f85063_t_p.html#aa75c703ccb7cfbdb89439151f0bc082c',1,'PCF85063TP::set()'],['../class_p_c_f85263_a.html#afb67e2345588ac0ffe0b604085f15558',1,'PCF85263A::set()'],['../class_p_c_f85053_a.html#aeb4f154de3223e3a0cb421596da855b0',1,'PCF85053A::set()'],['../class_for_future_extention.html#afae88fc08af5cec9fe3bfdffb6960759',1,'ForFutureExtention::set()']]],
  ['set_5fclock_5fout_4',['set_clock_out',['../class_p_c_f2131__base.html#a65efacf914d16fff371a7dcb56a5d25d',1,'PCF2131_base']]],
  ['spi_5ffor_5frtc_5',['SPI_for_RTC',['../class_s_p_i__for___r_t_c.html',1,'']]],
  ['started_6',['Getting started',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['supported_20devices_7',['Supported devices',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
