var searchData=
[
  ['board_0',['board',['../class_r_t_c___n_x_p.html#a8f59c56b982f126c9618f70ea63ac24e',1,'RTC_NXP']]]
];
